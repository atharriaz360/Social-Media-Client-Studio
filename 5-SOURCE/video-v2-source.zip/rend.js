const {chromium}=require('playwright');const {spawn}=require('child_process');
(async()=>{const b=await chromium.launch({args:['--allow-file-access-from-files']});const p=await b.newPage({viewport:{width:1440,height:1080}});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/v/scene.html');await p.evaluate(()=>window.ready);
const N=435;const ff=spawn('ffmpeg',['-y','-v','error','-f','image2pipe','-framerate','30','-i','-','-c:v','libx264','-profile:v','high','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-r','30','-movflags','+faststart','-an','out.mp4']);
ff.stderr.on('data',d=>process.stderr.write(d));
const t0=Date.now();
for(let f=0;f<N;f++){await p.evaluate(t=>render(t),f/30);const buf=await p.screenshot({type:'png'});if(!ff.stdin.write(buf))await new Promise(r=>ff.stdin.once('drain',r));if(f%60==0)console.log(f,(Date.now()-t0)/1000)}
ff.stdin.end();await new Promise(r=>ff.on('close',r));console.log('done',errs);await b.close()})();
