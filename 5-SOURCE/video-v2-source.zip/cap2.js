const {chromium}=require('playwright');const fs=require('fs');
async function run(b,W,H,dsf,pre){
const ctx=await b.newContext({viewport:{width:W,height:H},deviceScaleFactor:dsf});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));const box={};
const css=async()=>p.addStyleTag({content:'::-webkit-scrollbar{display:none}*{scrollbar-width:none}'});
const bb=async(k,sel)=>{const h=await p.$(sel);if(h){const r=await h.boundingBox();if(r)box[k]=[r.x+r.width/2,r.y+r.height/2,r.width,r.height]}};
const shot=async(n,w=500)=>{await p.waitForTimeout(w);await p.screenshot({path:`s/${pre}-${n}.png`})};
const go=async h=>{await p.evaluate(h=>location.hash=h,h);await p.waitForTimeout(3500)};
await p.goto('file:///home/claude/v/app.html');await p.waitForTimeout(1500);await css();
await bb('nav-brief','.sidebar [href="#brief"], nav [href="#brief"], a[href="#brief"]');await bb('runchecks','text=Run checks');
await shot('ov0');
await go('brief');await bb('brief-prog','.meter');await shot('brief');
await go('overview');
await p.click('text=Run checks');await p.waitForTimeout(500);await bb('facts','#editor label:has(input[name=facts])');await bb('save','#editor button[type=submit]');await shot('edit0',100);
await p.click('#editor label:has(input[name=facts])');await shot('edit1',350);
await p.click('#editor button[type=submit]');await bb('donut','.donut');await bb('approve','button[data-approve="P001"]');await shot('ov1',300);
await p.click('button[data-approve="P001"]');await p.waitForTimeout(500);await bb('evidence','#approval input[name=evidence]');await bb('record','#approval button.btn-primary');await shot('appr0',100);
const ev='Email from Avery · v1 approved';
for(let i=1;i<=6;i++){const n=Math.round(ev.length*i/6);await p.fill('#approval input[name=evidence]',ev.slice(0,n));await shot('apprt'+i,60)}
await p.check('#approval input[value=Approved]');await p.click('#approval button.btn-primary');await bb('donut2','.donut');await shot('ov2',350);
await go('overview');await shot('ov2clean',10);
await bb('nav-rep','a[href="#reports"]');
await go('reports');await bb('kpi','.kpi-hero, .kpis');await shot('rep',10);
await go('overview');await bb('avatar','.profile-menu summary');
await p.evaluate(()=>{const m=document.querySelector('.profile-menu');if(m)m.open=true});await bb('theme','#theme');await shot('menu',300);
await p.evaluate(()=>document.getElementById('theme').click());await shot('dark',350);
await p.waitForTimeout(3500);await shot('darkclean',10);
fs.writeFileSync(`s/${pre}-boxes.json`,JSON.stringify(box,null,1));console.log(pre,errs,Object.keys(box));await ctx.close()}
(async()=>{const b=await chromium.launch();await run(b,1440,936,2,'d');await run(b,393,852,3,'p');await b.close()})();
