import numpy as np, cv2
from scipy import ndimage
U='/mnt/user-data/uploads/Brief-to-Approved/'
S=1.75
bg=cv2.imread(U+'5-SOURCE/_Canva-BG/1.jpg')
bg=cv2.resize(bg,None,fx=S,fy=S,interpolation=cv2.INTER_LANCZOS4)
H,W=bg.shape[:2]
b,g,r=[bg[:,:,i].astype(np.float32) for i in range(3)]
# green key: how much green exceeds max(r,b)
k=np.clip((g-np.maximum(r,b)-40)/60,0,1)
hard=k>0.5
lab,n=ndimage.label(hard)
sizes=ndimage.sum(hard,lab,range(1,n+1))
order=np.argsort(sizes)[::-1][:2]
comps=[lab==i+1 for i in order]

def corners(m):
    ys,xs=np.where(m)
    s=xs+ys; d=xs-ys
    tl=(xs[s.argmin()],ys[s.argmin()]); br=(xs[s.argmax()],ys[s.argmax()])
    tr=(xs[d.argmax()],ys[d.argmax()]); bl=(xs[d.argmin()],ys[d.argmin()])
    return np.float32([tl,tr,br,bl])

def lines_quad(m,xr=None,yr=None):
    ys,xs=np.where(m)
    X0,X1=xs.min(),xs.max(); Y0,Y1=ys.min(),ys.max()
    xr=xr or (X0,X1); yr=yr or (Y0,Y1)
    def fitx(cols,fn):  # y as function of x
        pts=[(x,fn(np.where(m[:,x])[0])) for x in cols if m[:,x].any()]
        p=np.array(pts,float); return np.polyfit(p[:,0],p[:,1],1)
    def fity(rows,fn):
        pts=[(fn(np.where(m[y,:])[0]),y) for y in rows if m[y,:].any()]
        p=np.array(pts,float); return np.polyfit(p[:,1],p[:,0],1)
    wx=xr[1]-xr[0]; wy=yr[1]-yr[0]
    top=fitx(range(int(xr[0]+.15*wx),int(xr[0]+.4*wx)),np.min)
    bot=fitx(range(int(xr[0]+.1*wx),int(xr[0]+.6*wx)),np.max)
    lef=fity(range(int(yr[0]+.2*wy),int(yr[0]+.8*wy)),np.min)
    rig=fity(range(int(yr[0]+.08*wy),int(yr[0]+.25*wy)) if xr!=(X0,X1) else range(int(yr[0]+.2*wy),int(yr[0]+.8*wy)),np.max)
    def inter(lx,ly): # y=a x+b ; x=c y+d
        a,b=lx; c,d=ly; y=(a*d+b)/(1-a*c); return (c*y+d,y)
    return np.float32([inter(top,lef),inter(top,rig),inter(bot,rig),inter(bot,lef)])

def fit(scr_path,m,pad=6,quad=None,padbottom=0):
    scr=cv2.imread(scr_path)
    if padbottom:
        col=scr[-5:,:,:].reshape(-1,3).mean(0)
        ext=np.zeros((padbottom,scr.shape[1],3),np.uint8); ext[:]=np.uint8(col)
        scr=np.vstack([scr,ext])
    h,w=scr.shape[:2]
    c=quad if quad is not None else corners(m)
    cen=c.mean(0); c=cen+(c-cen)*(1+pad/np.linalg.norm(c-cen,axis=1,keepdims=True))
    M=cv2.getPerspectiveTransform(np.float32([[0,0],[w,0],[w,h],[0,h]]),np.float32(c))
    return cv2.warpPerspective(scr,M,(W,H),flags=cv2.INTER_AREA,borderMode=cv2.BORDER_REPLICATE)

lap_m,ph_m=(comps[0],comps[1]) if comps[0].sum()>comps[1].sum() else (comps[1],comps[0])
print('laptop',corners(lap_m)); print('phone',corners(ph_m))
lq=lines_quad(lap_m,xr=(int(401*S),int(980*S)),yr=(int(465*S),int(945*S))); print('lq',lq)
pq=lines_quad(ph_m,yr=None); print('pq',pq)
lap=fit(U+'6-ETSY-LISTING/_Screens-Latest/desktop-light-approvals.png',lap_m,quad=lq)
pr=np.linalg.norm(pq[3]-pq[0])/np.linalg.norm(pq[1]-pq[0]); pb=int(1179*pr*0.92-2556); print('phone ratio',pr,pb)
ph=fit('/tmp/claude-0/w/phone_src.png',ph_m,pad=4,quad=pq)
# soft alpha from key, restricted near components
near_l=ndimage.binary_dilation(lap_m,iterations=6); near_p=ndimage.binary_dilation(ph_m,iterations=6)
a=cv2.GaussianBlur(k,(0,0),0.8)
al=(a*near_l)[...,None]; ap=(a*near_p)[...,None]
out=bg.astype(np.float32)
# despill edges: clamp green to max(r,b)
spill=np.minimum(g,np.maximum(r,b)); out[:,:,1]=np.where((near_l|near_p)&(k<0.5),spill,g)
out=out*(1-al)+lap*al
out=out*(1-ap)+ph*ap
# subtle glass reflection: diagonal gradient on screens only
yy,xx=np.mgrid[0:H,0:W].astype(np.float32)
refl=np.clip(1-((xx-W*0.35)+(yy-H*0.3))/(W*0.9),0,1)**3*22
scrn=(al+ap)[...,0]
out+= (refl*scrn)[...,None]
out=np.clip(out,0,255).astype(np.uint8)
cv2.imwrite('/tmp/claude-0/w/plate_raw.png',out)
# build 3000x2250 canvas, offset
CW,CH=3000,2250
ox,oy=546,-10
canvas=np.zeros((CH,CW,3),np.uint8)
# edge-extend: pad then blur pad area
padL=ox; padR=max(0,CW-(ox+W))
padB=max(0,CH-(oy+H)+10)
ext=cv2.copyMakeBorder(out,0,padB,padL,padR,cv2.BORDER_REFLECT)
blur=cv2.GaussianBlur(ext,(0,0),40)
wmask=np.ones(ext.shape[:2],np.float32)
wmask[:, :padL]=0; wmask[:, padL+W:]=0; wmask[H:,:]=0
wmask=cv2.GaussianBlur(wmask,(0,0),25); wmask[:,padL+60:padL+W-60]=1
ext=(ext*wmask[...,None]+blur*(1-wmask[...,None])).astype(np.uint8)
y0=max(0,-oy)
if oy>0:
    ext=cv2.copyMakeBorder(ext,oy,0,0,0,cv2.BORDER_REFLECT); y0=0
canvas=ext[y0:y0+CH,0:CW]
# film grain on background only (not screens)
scr_mask=np.zeros((H,W),np.float32); scr_mask=(al+ap)[...,0]
sm=cv2.copyMakeBorder(scr_mask,max(0,oy),padB,padL,padR,cv2.BORDER_CONSTANT,value=0)[y0:y0+CH,0:CW]
rng=np.random.default_rng(7)
grain=rng.normal(0,3.2,(CH,CW)).astype(np.float32)
canvas=np.clip(canvas.astype(np.float32)+(grain*(1-sm))[...,None],0,255).astype(np.uint8)
cv2.imwrite('/tmp/claude-0/w/plate.png',canvas)
print(canvas.shape)
