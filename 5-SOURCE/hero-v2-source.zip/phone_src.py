from PIL import Image, ImageDraw, ImageFont
import sys
U='/mnt/user-data/uploads/Brief-to-Approved/6-ETSY-LISTING/_Screens-Latest/'
ratio=float(sys.argv[1]) if len(sys.argv)>1 else 2.17
scr=Image.open(U+'phone-light-approvals.png').convert('RGB')
W=1179; SB=162
H=int(W*ratio)
out=Image.new('RGB',(W,H),(255,255,255))
out.paste(scr,(0,SB))
d=ImageDraw.Draw(out)
ink=(18,18,22)
f=ImageFont.truetype('/tmp/claude-0/w/inter.ttf',54) if False else None
try:
    f=ImageFont.truetype('/tmp/claude-0/w/inter-latin-wght-normal.woff2',54)
    try: f.set_variation_by_axes([620])
    except Exception: pass
except Exception:
    f=ImageFont.truetype('DejaVuSans-Bold.ttf',50)
cy=92  # vertical centre of status items (aligned with Dynamic Island)
t='9:41'; tw=d.textlength(t,font=f)
d.text((200-tw/2,cy),t,font=f,fill=ink,anchor='lm')
# right cluster: signal, wifi, battery  (iOS order)
x=830
# signal: 4 bars
for i in range(4):
    h=14+i*9; bx=x+i*17
    d.rounded_rectangle((bx,cy+20-h,bx+11,cy+20),radius=3,fill=ink)
x+=4*17+22
# wifi: 3 arcs + dot
import math
cx,cyw=x+30,cy+22
for r,w in [(36,9),(24,9)]:
    d.arc((cx-r,cyw-r,cx+r,cyw+r),start=225,end=315,fill=ink,width=w)
d.pieslice((cx-13,cyw-13,cx+13,cyw+13),start=225,end=315,fill=ink)
x+=60+22
# battery
bw,bh=74,36
d.rounded_rectangle((x,cy-bh/2,x+bw,cy+bh/2),radius=11,outline=(140,140,146),width=4)
d.rounded_rectangle((x+7,cy-bh/2+7,x+bw-14,cy+bh/2-7),radius=6,fill=ink)
d.rounded_rectangle((x+bw+4,cy-8,x+bw+10,cy+8),radius=3,fill=(140,140,146))
# fade the app's bottom into page background, then home indicator
bot=SB+scr.height
if H>bot:
    col=scr.getpixel((W//2,scr.height-3))
    d.rectangle((0,bot,W,H),fill=(251,250,253))
hw=420; d.rounded_rectangle((W/2-hw/2,H-42,W/2+hw/2,H-27),radius=8,fill=ink)
out.save('/tmp/claude-0/w/phone_src.png')
out.crop((0,0,W,400)).save('/tmp/claude-0/w/phone_src_top.png')
print(out.size, bot)
